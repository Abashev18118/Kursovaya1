﻿namespace Kursovaya1
{
    public class Class1
    {

    }
}
